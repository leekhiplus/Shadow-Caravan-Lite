# Shadow Caravan Lite

A tiny 2D dark-fantasy desert game for Android, made with Godot 4.3 and GDScript.
Everything is drawn in code: no external assets, no internet, no ads.

**Play:** hold the left/right pads (bottom-left) to move, tap anywhere on the right side to jump.
Dodge the ember-edged spikes and slabs, grab golden coins, survive as long as you can.
On desktop: arrow keys to move, Space or Up to jump.

## Files

| File | Purpose |
|------|---------|
| `project.godot` | Godot project settings (landscape, 960x540, GL Compatibility) |
| `main.tscn` / `main.gd` | The whole game |
| `icon.svg` | Project icon |
| `export_presets.cfg` | Android export preset (`build/ShadowCaravanLite.apk`) |
| `.github/workflows/android-build.yml` | CI that builds the APK |

## Upload to GitHub

`project.godot` must sit at the **root** of the repository.

1. Create a new empty repository on github.com (no README, no .gitignore).
2. Unzip `ShadowCaravanLite.zip`, open a terminal inside the `ShadowCaravanLite` folder, then run:

```
git init -b main
git add .
git commit -m "Shadow Caravan Lite"
git remote add origin https://github.com/YOUR_USER/YOUR_REPO.git
git push -u origin main
```

(Web-only alternative: use **Add file > Upload files** for everything except the workflow, then
**Add file > Create new file**, type the name `.github/workflows/android-build.yml`, and paste the
file contents. Hidden folders are often skipped by drag-and-drop.)

## Get the APK

1. Open the repository's **Actions** tab. The build starts automatically on every push
   (or pick **Build Android APK > Run workflow**). The first run takes several minutes because
   it downloads Godot and its export templates.
2. When the run is green, open it and scroll to **Artifacts**.
3. Download **ShadowCaravanLite-apk** (a zip containing `ShadowCaravanLite.apk`).
4. Copy the APK to your phone and open it. Android will ask you to allow installing from
   this source.

## Notes

- The APK is signed with a throwaway debug key generated in CI. That is fine for sideloading,
  but not for Google Play (you would need your own release keystore).
- It includes `armeabi-v7a` and `arm64-v8a` builds so it runs on 32-bit and 64-bit phones.
  To make it smaller, set `architectures/armeabi-v7a=false` in `export_presets.cfg`.
- Godot version is pinned by `GODOT_VERSION` in the workflow. If you change it, check that
  the matching export templates exist and that the Android SDK build-tools version still fits.
- To build locally: open the folder in Godot 4.3, set up the Android SDK in
  Editor Settings, then **Project > Export > Android**.
